/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pablo
 */
public class carta {

    private int numero;
    private palo palo;

    public carta(int numero, palo palo) {
        this.numero = numero;
        this.palo = palo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getPalo() {
        if (this.palo == palo.PICAS) {
            return "\u2660";
        }
        if (this.palo == palo.TREBOLES) {
            return "\u2663";
        }
        if (this.palo == palo.CORAZONES) {
            return "\u2665";
        }
        return "\u2666";
    }

    @Override
    public String toString() {
        String MuestraNumero = "", MuestraPalo = "";
        switch (this.numero) {
            case 1:
                MuestraNumero = "A";
                break;
            case 11:
                MuestraNumero = "J";
                break;
            case 12:
                MuestraNumero = "Q";
                break;
            case 13:
                MuestraNumero = "K";
                break;
            default:
                MuestraNumero = "" + this.numero;
                break;

        }
        switch (this.palo) {
            case PICAS:
                MuestraPalo = "\u2660";
                break;
            case TREBOLES:
                MuestraPalo = "\u2663";
                break;
            case CORAZONES:
                MuestraPalo = "\u2665";
                break;
            case DIAMANTES:
                MuestraPalo = "\u2666";
                break;
        }

        return "" + MuestraNumero + MuestraPalo;
    }

}
